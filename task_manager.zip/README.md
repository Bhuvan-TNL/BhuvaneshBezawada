# 📚 Flask Task Manager App

A simple CRUD Task Manager built with **Flask** and **SQLite**.

## Features
- Add, Edit, Delete Tasks
- Mark as Complete / Incomplete
- Responsive UI with basic CSS

## Setup Instructions

```bash
git clone https://github.com/yourusername/task-manager-flask.git
cd task-manager-flask
pip install -r requirements.txt
python app.py
```

Visit: [http://localhost:5000](http://localhost:5000)

## License
MIT
