
from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)
DB_NAME = 'tasks.db'

def init_db():
    with sqlite3.connect(DB_NAME) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT,
                done BOOLEAN DEFAULT 0
            )
        """)

init_db()

@app.route('/')
def index():
    with sqlite3.connect(DB_NAME) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM tasks')
        tasks = cursor.fetchall()
    return render_template('index.html', tasks=tasks)

@app.route('/add', methods=['POST'])
def add():
    title = request.form['title']
    desc = request.form['description']
    with sqlite3.connect(DB_NAME) as conn:
        conn.execute('INSERT INTO tasks (title, description) VALUES (?, ?)', (title, desc))
    return redirect(url_for('index'))

@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit(id):
    if request.method == 'POST':
        title = request.form['title']
        desc = request.form['description']
        with sqlite3.connect(DB_NAME) as conn:
            conn.execute('UPDATE tasks SET title=?, description=? WHERE id=?', (title, desc, id))
        return redirect(url_for('index'))
    else:
        with sqlite3.connect(DB_NAME) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM tasks WHERE id=?', (id,))
            task = cursor.fetchone()
        return render_template('edit.html', task=task)

@app.route('/delete/<int:id>')
def delete(id):
    with sqlite3.connect(DB_NAME) as conn:
        conn.execute('DELETE FROM tasks WHERE id=?', (id,))
    return redirect(url_for('index'))

@app.route('/toggle/<int:id>')
def toggle(id):
    with sqlite3.connect(DB_NAME) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT done FROM tasks WHERE id=?', (id,))
        done = cursor.fetchone()[0]
        conn.execute('UPDATE tasks SET done=? WHERE id=?', (not done, id))
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
