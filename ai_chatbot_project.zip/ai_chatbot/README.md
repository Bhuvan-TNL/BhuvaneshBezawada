
# 🤖 AI Chatbot using Flask & TensorFlow

This is a basic AI chatbot built using Flask and TensorFlow for natural language understanding and intent classification.

## ✨ Features
- Trained using a simple NLP pipeline (tokenizing, lemmatizing)
- TensorFlow neural network model
- Flask API backend
- HTML/JS frontend for chatting

## 📦 Installation
```bash
git clone https://github.com/yourusername/ai_chatbot.git
cd ai_chatbot
pip install -r requirements.txt
```

## 🧠 Train the Model
```bash
python train_chatbot.py
```

## 🚀 Run the App
```bash
python app.py
```

Then open `http://127.0.0.1:5000` in your browser.

## 📁 Project Structure
- `intents.json`: Training data
- `train_chatbot.py`: Script to train the model
- `app.py`: Flask web app
- `templates/index.html`: Frontend UI
- `static/style.css`: CSS styling
- `chatbot_model.h5`, `words.pkl`, `classes.pkl`: Trained model files

## 📄 License
MIT License
